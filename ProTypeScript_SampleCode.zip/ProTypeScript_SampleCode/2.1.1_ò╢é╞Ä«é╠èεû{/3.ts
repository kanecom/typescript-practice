const greeting = "Hello, ";
const text = greeting + "world!";
// "Hello, world!" と表示される
console.log(text);
