const greeting = "Hello, ";
const target = greeting;
// "Hello, Hello," と表示される
console.log(greeting + target);
