const greeting = "Hello, ";
const target = "world!";
console.log(greeting + target);