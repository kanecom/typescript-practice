console.log("foo" + true); // "footrue" と表示される
console.log(null + "bar"); // "nullbar" と表示される
