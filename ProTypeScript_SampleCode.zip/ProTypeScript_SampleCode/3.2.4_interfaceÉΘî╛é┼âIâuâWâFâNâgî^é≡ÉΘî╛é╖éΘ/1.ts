interface FooBarObj {
  foo: number;
  bar: string;
}
const obj: FooBarObj = {
  foo: 0,
  bar: "string"
};