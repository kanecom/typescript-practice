const uhyoAge = 26;

export {
  uhyoAge as default
};