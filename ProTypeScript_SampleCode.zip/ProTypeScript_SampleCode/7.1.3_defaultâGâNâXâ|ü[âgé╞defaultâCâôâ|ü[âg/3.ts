let value = 0;

export default function increment() {
  return ++value;
}