// defaultインポートの構文を使う書き方
import increment, { value } from "./counter.js";
// defaultインポートの構文を使わない書き方
import { default as increment, value } from "./counter.js";