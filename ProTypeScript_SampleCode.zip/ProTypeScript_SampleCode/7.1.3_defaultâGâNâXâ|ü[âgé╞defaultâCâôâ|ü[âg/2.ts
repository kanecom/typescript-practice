import uhyoAge from "./uhyoAge.js";

console.log(`uhyoの年齢は${uhyoAge}です`); // "uhyoの年齢は26です" と表示される