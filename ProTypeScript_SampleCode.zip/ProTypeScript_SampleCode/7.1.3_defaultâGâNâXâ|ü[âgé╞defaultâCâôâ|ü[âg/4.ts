import increment from "./counter.js";

console.log(`カウンタの値は${increment()}です`);
console.log(`カウンタの値は${increment()}です`);
console.log(`カウンタの値は${increment()}です`);