
while (true) {
  if (i > 100) {
    break;
  }
  sum += i;
  i++;
}