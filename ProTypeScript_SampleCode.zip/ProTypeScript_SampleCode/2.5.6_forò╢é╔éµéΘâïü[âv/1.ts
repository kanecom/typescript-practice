let sum = 0;
for (let i: number = 1; i <= 100; i++) {
  sum += i;
}
console.log(sum); // 5050 が表示される