let foo = 10;
foo++;
console.log(foo); // 11 が表示される
--foo;
console.log(foo); // 10 が表示される