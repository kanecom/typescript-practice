let foo = 10;
console.log(++foo); // 変動後の値 11 が表示される
console.log(foo--); // 変動前の値 11 が表示される