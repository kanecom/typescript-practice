const str: string = '123';
console.log(+str * 100); // 12300が表示される