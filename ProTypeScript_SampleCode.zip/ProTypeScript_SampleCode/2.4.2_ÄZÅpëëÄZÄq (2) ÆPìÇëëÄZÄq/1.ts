const x = 123;
const minusx = -x; // minusxはnumber型
console.log(minusx); // -123 と表示される
