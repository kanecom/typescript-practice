function useUhyo(name: "uhyo") {
  // （略）
}