const obj = {
  foo: 123,
  bar: "Hello, world!",
};

console.log(obj.foo); // 123 と表示される
console.log(obj.bar); // "Hello, world!" と表示される
