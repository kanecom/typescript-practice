const uhyo = new User("uhyo", 26);
// "uhyo (26) 「こんにちは」" と表示される
console.log(uhyo.getMessage("こんにちは"));