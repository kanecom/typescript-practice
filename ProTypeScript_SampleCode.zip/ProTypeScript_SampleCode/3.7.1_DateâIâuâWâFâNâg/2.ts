const d = new Date("2020-02-03T15:00:00+09:00");
console.log(d);