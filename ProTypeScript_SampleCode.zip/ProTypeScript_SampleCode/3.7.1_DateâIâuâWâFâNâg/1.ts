const d = new Date();
console.log(d); // 現在の日付と時刻が表示される