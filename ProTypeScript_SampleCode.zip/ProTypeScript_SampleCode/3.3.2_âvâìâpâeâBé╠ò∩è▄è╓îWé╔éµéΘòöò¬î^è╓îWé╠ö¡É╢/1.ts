type Animal = {
  age: number;
};
type Human = {
  age: number;
  name: string;
}