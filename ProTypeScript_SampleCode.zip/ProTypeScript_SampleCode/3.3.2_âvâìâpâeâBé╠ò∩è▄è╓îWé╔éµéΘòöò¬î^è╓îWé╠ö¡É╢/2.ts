type AnimalFamily = {
  familyName: string;
  mother: Animal;
  father: Animal;
  child: Animal;
}
type HumanFamily = {
  familyName: string;
  mother: Human;
  father: Human;
  child: Human;
}