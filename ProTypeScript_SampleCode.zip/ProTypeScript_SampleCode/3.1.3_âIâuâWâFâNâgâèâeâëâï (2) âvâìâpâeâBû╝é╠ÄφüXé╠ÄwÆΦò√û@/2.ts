const obj = {
    1: "one",
    2.05: "two point o five",
};
console.log(obj["1"]); // "one" と表示される
console.log(obj["2.05"]); // "two point o five" と表示される
