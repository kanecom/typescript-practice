const propName = "foo";
const obj = {
  [propName]: 123,
};

console.log(obj.foo); // 123 と表示される
