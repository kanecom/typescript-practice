const result = line + 1000;
console.log(result);
rl.close();