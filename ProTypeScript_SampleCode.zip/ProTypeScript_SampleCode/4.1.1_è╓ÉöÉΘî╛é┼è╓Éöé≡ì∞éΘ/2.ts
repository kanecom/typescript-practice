// エラー: Argument of type 'string' is not assignable to parameter of type 'number'.
range("5", "10");
// エラー: Expected 2 arguments, but got 1.
range(5);