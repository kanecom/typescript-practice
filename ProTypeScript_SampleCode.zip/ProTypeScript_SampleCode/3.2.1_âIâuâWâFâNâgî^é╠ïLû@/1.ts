const obj = {
  foo: 123,
  bar: "Hello, world!"
};