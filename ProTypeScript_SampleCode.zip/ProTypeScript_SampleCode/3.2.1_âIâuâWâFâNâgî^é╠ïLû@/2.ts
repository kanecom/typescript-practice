const obj: {
  foo: number;
  bar: string;
}