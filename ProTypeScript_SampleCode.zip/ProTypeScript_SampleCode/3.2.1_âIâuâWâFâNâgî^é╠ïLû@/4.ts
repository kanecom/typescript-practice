const obj: {
  "foo bar": number;
} = {
  "foo bar": 123,
};