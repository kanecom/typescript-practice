const obj: {
  foo: number;
  bar: string;
} = {
  foo: 123,
  bar: "Hello, world!"
};