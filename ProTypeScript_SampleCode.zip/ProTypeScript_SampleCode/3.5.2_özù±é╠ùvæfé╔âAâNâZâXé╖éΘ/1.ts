const arr = [0, 123, -456 * 100];
console.log(arr[0]); // 0 が表示される
console.log(arr[1]); // 123 が表示される