if (customer instanceof User && customer.name === "uhyo") {
  return 0;
}