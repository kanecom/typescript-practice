const val1 = null;
const val2 = undefined;

console.log(val1, val2); // null undefined と表示される