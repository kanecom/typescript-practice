const n: null = null;
const u: undefined = undefined;