console.log(typeof "uhyo"); // "string" と表示される
console.log(typeof 26); // "number" と表示される
console.log(typeof {}); // "object" と表示されaる
console.log(typeof undefined); // "undefined" と表示される