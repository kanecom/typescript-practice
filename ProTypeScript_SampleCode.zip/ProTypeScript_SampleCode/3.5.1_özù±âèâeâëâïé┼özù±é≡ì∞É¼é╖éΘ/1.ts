const arr = [0, 123, -456 * 100];
console.log(arr);