const arr1 = [4, 5, 6];
const arr2 = [1, 2, 3, ...arr1];

console.log(arr2); // [1, 2, 3, 4, 5, 6] が表示される