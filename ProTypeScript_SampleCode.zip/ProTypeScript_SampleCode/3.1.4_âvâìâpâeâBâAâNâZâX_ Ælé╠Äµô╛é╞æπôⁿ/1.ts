const user = {
  name: "uhyo",
  age: 25,
};

user.age = 26;
console.log(user.age); // 26 が表示される