const g = (num: number) => {
  for (let i = 0; i < num; i++) {
    console.log("Hello, world!");
  }
};