type User = [name: string, age: number];

const uhyo: User = ["uhyo", 26];

console.log(uhyo[1]); // 26 と表示される