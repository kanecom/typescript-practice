// エラー: Type 'number' does not satisfy the constraint 'HasName'.
type T = Family<number, string>;