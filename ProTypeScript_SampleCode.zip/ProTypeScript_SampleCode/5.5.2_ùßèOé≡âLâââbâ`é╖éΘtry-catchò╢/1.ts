try {
  // tryブロック（ここは文を複数書ける）
} catch (err) {
  // catchブロック（ここも文を複数書ける）
}