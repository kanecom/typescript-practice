type User =
  | Animal
  | Human;