type F = (arg: string) => number;
type G = { (arg: string): number; };