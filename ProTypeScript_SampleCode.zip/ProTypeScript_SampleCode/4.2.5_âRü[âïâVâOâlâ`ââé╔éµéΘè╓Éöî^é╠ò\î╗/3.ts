type SwapFunc = {
  (arg: string): number;
  (arg: number): boolean;
}