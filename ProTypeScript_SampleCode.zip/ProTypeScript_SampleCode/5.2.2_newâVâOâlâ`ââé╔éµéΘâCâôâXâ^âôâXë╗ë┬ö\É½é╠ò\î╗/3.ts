type MyUserConstructor = {
  new (): User;
};