class User {
  name: string = "";
  age: number = 0;
}