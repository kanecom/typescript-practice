const big = 1e8;
const small = 4e-5;

// 100000000 0.00004 と表示される
console.log(big, small);