const binary = 0b1010;    // 2進数リテラル
const octal = 0o755;      // 8進数リテラル
const hexadecimal = 0xff; // 16進数リテラル

// 10 493 255 と表示される
console.log(binary, octal, hexadecimal);