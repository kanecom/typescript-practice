const million = 1_000_000;

// 1000000 と表示される
console.log(million);