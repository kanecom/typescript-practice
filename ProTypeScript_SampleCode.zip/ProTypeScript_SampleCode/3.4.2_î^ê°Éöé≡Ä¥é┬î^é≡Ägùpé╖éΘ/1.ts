const obj: Family<number, string> = {
  mother: 0,
  father: 100,
  child: "1000"
};