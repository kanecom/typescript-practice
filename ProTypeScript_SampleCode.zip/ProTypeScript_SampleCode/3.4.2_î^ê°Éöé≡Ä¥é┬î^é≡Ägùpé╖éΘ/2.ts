// エラー: Generic type 'Family' requires 2 type argument(s).
const obj: Family = {
  mother: 0,
  father: 100,
  child: "1000"
}