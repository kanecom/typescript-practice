const foo = obj.foo;
const bar = obj.bar;