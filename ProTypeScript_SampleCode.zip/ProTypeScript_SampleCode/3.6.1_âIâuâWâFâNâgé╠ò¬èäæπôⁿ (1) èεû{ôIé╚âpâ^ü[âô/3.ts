const {
  foo,
  bar: barVar,
  "foo bar": fooBar
} = obj;