export type Animal = {
  species: string;
  age: number;
}