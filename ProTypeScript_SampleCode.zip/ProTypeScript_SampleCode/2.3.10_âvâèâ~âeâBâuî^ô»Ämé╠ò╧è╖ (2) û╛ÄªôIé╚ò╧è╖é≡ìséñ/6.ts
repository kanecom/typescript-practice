console.log(Boolean(123)); // true と表示される
console.log(Boolean(0)); // false と表示される
console.log(Boolean(1n)); // true と表示される
console.log(Boolean(0n)); // false と表示される
console.log(Boolean("")); // false と表示される
console.log(Boolean("foobar")); // true と表示される
console.log(Boolean(null)); // false と表示される
console.log(Boolean(undefined)); // false と表示される
