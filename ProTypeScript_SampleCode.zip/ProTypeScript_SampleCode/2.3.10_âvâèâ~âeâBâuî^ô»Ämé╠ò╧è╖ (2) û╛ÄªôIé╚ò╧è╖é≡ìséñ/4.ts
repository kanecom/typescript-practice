const bigint = BigInt("foooooo");

console.log("bigint is ", bigint);