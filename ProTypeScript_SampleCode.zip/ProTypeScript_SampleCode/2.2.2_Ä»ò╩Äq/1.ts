const あいう = 123;
const 技術評論社 = あいう + 876;
console.log(技術評論社); // 999 と表示される