// エラー: Argument of type 'number' is not assignable to parameter of type 'string'.
repeat<string>(0, 10);