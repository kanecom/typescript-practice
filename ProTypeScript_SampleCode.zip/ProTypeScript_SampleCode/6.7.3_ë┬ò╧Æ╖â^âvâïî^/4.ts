type NSN = [number, string, number];
// SNSNSは [string, number, string, number, string] 型
type SNSNS = [string, ...NSN, string];