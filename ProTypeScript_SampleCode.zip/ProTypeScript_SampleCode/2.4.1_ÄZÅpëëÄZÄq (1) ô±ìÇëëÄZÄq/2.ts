// res1の型はnumber型
const res1 = 5 - 1.86;
// res2の型はbigint型
const res2 = 2n ** 5n;
