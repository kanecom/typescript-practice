console.log(5 - 3 - 1);   // 1 と表示される
console.log((5 - 3) - 1); // 1 と表示される
console.log(5 - (3 - 1)); // 3 と表示される