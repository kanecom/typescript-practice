let foo: string = "文字列";
// エラー: Type 'number' is not assignable to type 'string'.
foo = 123;
