let num = 0;
num += 100; // numは100 (0 + 100)
num *= 4; // numは400 (100 * 4)
num -= 200; // numは200 (400 - 200)
num /= 2; // numは100 (200 / 2)
num **= 0.5; // numは10 (100 ** 0.5)

console.log(num); // 10 と表示される
