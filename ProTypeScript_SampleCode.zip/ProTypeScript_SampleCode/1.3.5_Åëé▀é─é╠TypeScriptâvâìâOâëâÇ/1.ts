const message: string = "Hello, world!";

console.log(message);