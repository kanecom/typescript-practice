const message: number = "Hello, world!";

console.log(message);