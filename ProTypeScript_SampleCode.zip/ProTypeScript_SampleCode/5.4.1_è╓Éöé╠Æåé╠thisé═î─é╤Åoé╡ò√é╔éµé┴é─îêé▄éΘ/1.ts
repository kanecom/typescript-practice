const uhyo = new User("uhyo", 26);
const john = new User("John Smith", 15);

console.log(uhyo.isAdult === john.isAdult); // true が表示される