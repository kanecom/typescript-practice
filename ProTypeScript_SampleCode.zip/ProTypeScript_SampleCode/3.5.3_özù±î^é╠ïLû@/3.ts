// number[]型
const arr = [1, 10, 100];
// (string | number | boolean)[]型
const arr2 = [100, "文字列", false];