// これはOK
const arr: number[] = [1, 10, 100];
// これはコンパイルエラー
// エラー: Type 'number' is not assignable to type 'string'.
const arr2: string[] = [123, -456];