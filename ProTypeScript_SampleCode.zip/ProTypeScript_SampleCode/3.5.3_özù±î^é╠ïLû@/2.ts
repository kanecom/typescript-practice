// 簡単な型の配列
const arr1: boolean[] = [false, true];
// 複雑な型の配列
const arr2: Array<{
  name: string;
}> = [
  { name: "山田さん" },
  { name: "田中さん" },
  { name: "鈴木さん" }
];