const greeting = "Hello, ";
const target = "world!";
const text = greeting + target;
console.log(text);