const greeting = "Hello, ",
      target = "world!",
      text = greeting + target;
console.log(text);