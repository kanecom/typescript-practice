// Argument of type '"kg"' is not assignable to parameter of type '"mm" | "m" | "km"'.
convertUnits(5600, "kg");