function double(value: number) {
  console.log(value * 2);
}
function double(value: string) {
  console.log(value.repeat(2));
}

double(123);
double("hello");