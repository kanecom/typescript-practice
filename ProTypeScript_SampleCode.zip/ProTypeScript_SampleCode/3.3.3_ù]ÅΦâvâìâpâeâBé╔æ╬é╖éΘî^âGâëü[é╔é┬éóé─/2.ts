type User = { name: string; age: number };
const obj = {
  name: "uhyo",
  age: 26,
  telNumber: "09012345678"
};
const u: User = obj;