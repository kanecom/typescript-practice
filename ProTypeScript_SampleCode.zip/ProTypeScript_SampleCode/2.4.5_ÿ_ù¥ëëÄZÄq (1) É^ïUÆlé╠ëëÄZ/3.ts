if (!Number.isNaN(num)) {
  console.log(num, "はNaNではありません");
}