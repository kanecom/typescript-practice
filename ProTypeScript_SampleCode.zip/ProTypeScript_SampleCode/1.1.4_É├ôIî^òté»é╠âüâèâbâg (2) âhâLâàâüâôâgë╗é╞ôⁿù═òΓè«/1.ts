function repeatHello(count: number): string {
  return "hello".repeat(count);
}