// エラー: A required parameter cannot follow an optional parameter.
const toLowerOrUpper = (str?: string, upper: boolean): string => {