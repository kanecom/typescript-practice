const foo = { num: 1234 };
const bar = { num: 1234 };