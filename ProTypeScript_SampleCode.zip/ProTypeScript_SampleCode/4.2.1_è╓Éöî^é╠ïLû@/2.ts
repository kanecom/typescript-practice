type F = (repeatNum: number) => string;

const xRepeat: F = (num: number): string => "x".repeat(num);