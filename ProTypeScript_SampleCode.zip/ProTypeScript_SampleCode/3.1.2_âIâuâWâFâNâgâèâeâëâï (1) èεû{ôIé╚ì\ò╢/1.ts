const obj = {
  foo: 555,
  bar: "文字列",
};