const name = input ? input : "名無し";
const user = {
  name: name,
  age: 20,
};