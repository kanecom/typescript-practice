const user = {
  name: input ? input : "名無し",
  age: 20,
};