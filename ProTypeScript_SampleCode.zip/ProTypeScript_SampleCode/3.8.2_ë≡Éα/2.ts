[
  "",
  "uhyo,26,1",
  "John Smith,17,0",
  "Mary Sue,14,1",
  ""
]