[{
  "name": "uhyo",
  "age": 26,
  "premiumUser": true
}, {
  "name": "John Smith",
  "age": 17,
  "premiumUser": false
}, {
  "name": "Mary Sue",
  "age": 14,
  "premiumUser": true
}]