const nums = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const arr2 = nums.filter((x) => x % 3 === 0);
console.log(arr2); // [3, 6, 9] と表示される