// Parameter 'num' implicitly has an 'any' type.
const f = (num) => num * 2;