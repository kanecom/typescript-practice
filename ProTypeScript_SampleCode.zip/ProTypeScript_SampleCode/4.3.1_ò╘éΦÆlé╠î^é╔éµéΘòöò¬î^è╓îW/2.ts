const f = (name: string) => ({ name });
const g: (name: string) => void = f;