console.log("Hello");
class C {
  static {
    console.log("uhyo");
  }
}
console.log("world!");