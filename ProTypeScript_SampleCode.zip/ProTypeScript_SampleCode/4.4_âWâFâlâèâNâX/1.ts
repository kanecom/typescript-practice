type User<N> = {
  name: N;
}