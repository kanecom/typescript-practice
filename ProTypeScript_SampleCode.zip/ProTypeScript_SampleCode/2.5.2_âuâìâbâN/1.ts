if (userName === "") {
  console.log("名前を入力してください！");
  userName = "名無し";
}