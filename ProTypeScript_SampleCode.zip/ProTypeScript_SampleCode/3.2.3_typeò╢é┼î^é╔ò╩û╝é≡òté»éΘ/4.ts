type FooObj = { foo: number };
type MyObj = FooObj;

const obj: MyObj = { foo: 0 };