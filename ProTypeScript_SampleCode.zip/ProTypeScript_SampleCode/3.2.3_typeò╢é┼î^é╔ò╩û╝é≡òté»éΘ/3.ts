type UserId = string;
const id: UserId = "uhyo";