type Human = {
  species: string;
  age: number;
  name: string;
}