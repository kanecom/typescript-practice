console.log(obj.baz); // undefined と表示される
console.log(obj2.baz); // 1234 と表示される