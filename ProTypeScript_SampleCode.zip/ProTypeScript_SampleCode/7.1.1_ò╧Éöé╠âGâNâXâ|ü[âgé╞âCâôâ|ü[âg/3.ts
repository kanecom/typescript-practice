import { name, age } from "./uhyo.js";

console.log(`uhyoの名前は${name}で年齢は${age}です。`);