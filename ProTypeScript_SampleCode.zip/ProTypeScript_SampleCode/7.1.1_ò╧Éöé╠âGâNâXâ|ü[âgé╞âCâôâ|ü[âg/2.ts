import { name, age } from "./uhyo.js";

console.log(name, age); // uhyo 26 と表示される