export const name = "uhyo";
export const age = 26;