import { uhyoName, age } from "./uhyo.js";

console.log(`uhyoの名前は${uhyoName}で年齢は${age}です。`);