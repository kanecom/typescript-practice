import { uhyoName, age as uhyoAge } from "./uhyo.js";

console.log(`uhyoの名前は${uhyoName}で年齢は${uhyoAge}です。`);