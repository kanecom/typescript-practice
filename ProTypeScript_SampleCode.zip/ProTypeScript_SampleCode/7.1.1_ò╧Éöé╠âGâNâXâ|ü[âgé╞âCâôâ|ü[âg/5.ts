const name = "uhyo";
const age = 26;

export { name, age };