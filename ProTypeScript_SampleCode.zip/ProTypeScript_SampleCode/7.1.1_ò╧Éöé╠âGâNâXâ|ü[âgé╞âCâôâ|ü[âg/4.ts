console.log(`uhyoの名前は${name}で年齢は${age}です。`);

import { name, age } from "./uhyo.js";