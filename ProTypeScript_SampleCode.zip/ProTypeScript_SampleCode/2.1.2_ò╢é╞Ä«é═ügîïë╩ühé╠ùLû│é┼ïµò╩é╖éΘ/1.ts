if (i < 10) {
  console.log("iは10未満です");
}