let greeting: string, target: string;
greeting = "Hello, ";
target = "world!";
console.log(greeting + target);