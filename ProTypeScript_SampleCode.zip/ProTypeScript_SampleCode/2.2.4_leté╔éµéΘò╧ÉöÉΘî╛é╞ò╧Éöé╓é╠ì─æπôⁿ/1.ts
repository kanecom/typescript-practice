let greeting = "Hello, ";
let target = "world!";
console.log(greeting + target);