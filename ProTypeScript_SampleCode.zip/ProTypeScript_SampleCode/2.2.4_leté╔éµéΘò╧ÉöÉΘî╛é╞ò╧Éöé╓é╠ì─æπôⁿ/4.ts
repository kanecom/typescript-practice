let greeting, target;
greeting = "Hello, ";
target = "world!";
console.log(greeting + target);