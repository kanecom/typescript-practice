let greeting = "Hello, ";
greeting = greeting + "world!";
// "Hello, world!" が表示される
console.log(greeting);
