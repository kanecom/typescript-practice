let greeting: string, target: string;
greeting = "Hello, ";
console.log(greeting + target);