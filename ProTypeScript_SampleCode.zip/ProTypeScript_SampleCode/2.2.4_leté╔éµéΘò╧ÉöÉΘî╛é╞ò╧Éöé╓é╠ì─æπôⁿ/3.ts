const greeting = "Hello, ";
// エラー: Cannot assign to 'greeting' because it is a constant.
greeting = greeting + "world!";