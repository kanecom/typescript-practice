const arr = [1, 10, 100];

for (const elm of arr) {
  console.log(elm);
}