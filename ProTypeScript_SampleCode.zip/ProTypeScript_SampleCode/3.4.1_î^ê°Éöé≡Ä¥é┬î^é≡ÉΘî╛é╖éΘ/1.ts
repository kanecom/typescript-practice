type User<T> = {
  name: string;
  child: T;
};