type Family<Parent, Child> = {
  mother: Parent;
  father: Parent;
  child: Child;
};