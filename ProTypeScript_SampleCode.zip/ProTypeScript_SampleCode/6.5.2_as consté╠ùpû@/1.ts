// string[]型
const names1 = ["uhyo", "John", "Taro"];
// readonly ["uhyo", "John", "Taro"]型
const names2 = ["uhyo", "John", "Taro"] as const;