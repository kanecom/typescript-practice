type Name = "uhyo" | "John" | "Taro";

const names: Name[] = ["uhyo", "John", "Taro"];