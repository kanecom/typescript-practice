const str1: string = "Hello";
const str2: string = 'world!';
console.log(str1 + ", " + str2); // "Hello, world!" と表示される