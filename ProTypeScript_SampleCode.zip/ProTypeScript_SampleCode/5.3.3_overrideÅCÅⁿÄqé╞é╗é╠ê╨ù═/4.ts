class User {
  name: string;
  #age: number;

  constructor(name: string, age: number) {
    this.name = name;
    this.#age = age;
  }

  public isChild(): boolean {
    return this.#age < 20;
  }
}

class PremiumUser extends User {
  rank: number = 1;

  // オーバーライドのつもりだったが、オーバーライドではなくなってしまった！
  public isAdult(): boolean {
    return true;
  }
}