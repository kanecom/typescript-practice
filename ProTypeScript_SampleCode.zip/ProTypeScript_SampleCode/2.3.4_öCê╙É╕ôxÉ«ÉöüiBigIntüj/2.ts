const result = 5n / 2n;
console.log(result); // 2n と表示される