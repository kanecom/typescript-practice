const bignum: bigint = (123n + 456n) * 2n;
console.log(bignum); // 1158n と表示される