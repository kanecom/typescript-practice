function map(array: number[], callback: /* ここを埋める */): number[] {
  /* ここを埋める */
}

const data = [1, 1, 2, 3, 5, 8, 13];

const result = map(data, (x) => x * 10);
// [10, 10, 20, 30, 50, 80, 130] と表示される
console.log(result);