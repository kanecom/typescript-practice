if (userName !== "") {
  console.log("ちゃんと名前があってえらい！");
} else {
  console.log("名前を入力してください！");
  userName = "名無し";
}