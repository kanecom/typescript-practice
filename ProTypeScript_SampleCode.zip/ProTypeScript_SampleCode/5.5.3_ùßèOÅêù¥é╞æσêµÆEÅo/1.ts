try {
  someFunc();
} catch (err) {
  // 何もしない
}