try {
  someFunc();
} catch {
  // 何もしない
}