const result = "Hello, abbbbbbc world! abc".match(/a(b+)c/g);
console.log(result); // ["abbbbbbc", "abc"] と表示される