// エラー: A rest parameter must be of an array type.
const sum = (...args: number) => {
};