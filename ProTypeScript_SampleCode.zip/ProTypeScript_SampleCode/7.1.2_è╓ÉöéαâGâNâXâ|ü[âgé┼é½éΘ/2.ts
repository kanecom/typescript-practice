import { getUhyoName } from "./uhyo.js";

// "uhyoの名前はuhyoです" と表示される
console.log(`uhyoの名前は${getUhyoName()}です`);