export const getUhyoName = () => {
  return "uhyo";
};