let uhyo: string | number = "uhyo";

uhyo = "john";
uhyo = 3.14;