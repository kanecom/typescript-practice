type Human = {
  readonly name: string;
  readonly age: number;
};

const uhyo: Human = {
  name: "uhyo",
  age: 26
};