const uhyo = {
  name: "uhyo",
  age: 26
};

uhyo.name = "john";