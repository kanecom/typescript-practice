type Uhyo = {
  name: "uhyo";
  age: number;
};

const uhyo: Uhyo = {
  name: "uhyo",
  age: 26
};