const uhyo = {
  name: "uhyo",
  age: 26
};