// 変数uhyo1は"uhyo"型
const uhyo1 = "uhyo";
// 変数uhyo2はstring型
let uhyo2 = "uhyo";