type Human = {
  name: string;
  age?: number;
};

const john: Human = {
  name: "John Smith",
  age: undefined
};