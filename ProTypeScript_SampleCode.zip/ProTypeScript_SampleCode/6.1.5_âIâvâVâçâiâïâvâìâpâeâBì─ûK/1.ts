type Human = {
  name: string;
  age?: number;
};

const uhyo: Human = {
  name: "uhyo",
  age: 25
};

const john: Human = {
  name: "John Smith"
};