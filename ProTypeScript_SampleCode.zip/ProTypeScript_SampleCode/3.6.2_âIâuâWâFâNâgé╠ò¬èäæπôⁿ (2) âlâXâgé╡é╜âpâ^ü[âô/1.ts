const nested = {
  num: 123,
  obj: {
    foo: "hello",
    bar: "world"
  }
}