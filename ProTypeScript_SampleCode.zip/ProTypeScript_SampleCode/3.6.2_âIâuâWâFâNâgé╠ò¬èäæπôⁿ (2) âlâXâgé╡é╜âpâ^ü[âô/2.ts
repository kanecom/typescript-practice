const { num, obj: { foo } } = nested;

console.log(num); // 123 と表示される
console.log(foo); // "hello" と表示される