// これはwideningされる"uhyo"型
const uhyo1 = "uhyo";
// これはwideningされない"uhyo"型
const uhyo2: "uhyo" = "uhyo";

// これはstring型
let uhyo3 = uhyo1;
// これは"uhyo"型
let uhyo4 = uhyo2;