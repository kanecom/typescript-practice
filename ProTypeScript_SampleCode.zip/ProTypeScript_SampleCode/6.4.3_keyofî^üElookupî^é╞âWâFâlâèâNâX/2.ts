// エラー: Argument of type '"gender"' is not assignable to parameter of type 'keyof Human'.
const uhyoGender = get(uhyo, "gender");