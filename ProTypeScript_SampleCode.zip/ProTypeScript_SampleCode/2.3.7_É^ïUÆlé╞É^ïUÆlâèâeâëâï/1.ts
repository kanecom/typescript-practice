const no: boolean = false;
const yes: boolean = true;

console.log(yes, no); // true false と表示される