const greeting: string = "Hello, "
const target: string = 123;
console.log(greeting + target);