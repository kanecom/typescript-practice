const greeting: string = "Hello, ";
const target: string = "world!";
console.log(greeting + target);