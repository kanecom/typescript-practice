// 文字列のリテラル型
const foo: "foo" = "foo";
// 数値のリテラル型
const one: 1 = 1;
// 真偽値のリテラル型
const t: true = true;
// BigIntのリテラル型
const three: 3n = 3n;