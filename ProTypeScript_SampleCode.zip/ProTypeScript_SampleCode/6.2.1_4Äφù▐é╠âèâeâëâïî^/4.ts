// 変数uhyoNameは"uhyo"型
const uhyoName = "uhyo";
// 変数ageは26型
const age = 26;