const arr = [1, 2, 4, 8, 16, 32];

const [first, second, third] = arr;
console.log(first); // 1 が表示される
console.log(second); // 2 が表示される
console.log(third); // 4 が表示される