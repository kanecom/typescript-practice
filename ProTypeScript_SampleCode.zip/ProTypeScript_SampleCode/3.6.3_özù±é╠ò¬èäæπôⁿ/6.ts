const tuple: [string, number] = ["uhyo", 26];
// myNameはstring型、ageはnumber型になる
const [myName, age] = tuple;

console.log(myName); // "uhyo" と表示される
console.log(age); // 26 と表示される