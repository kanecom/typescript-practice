const first = arr[0];
const second = arr[1];
const third = arr[2];