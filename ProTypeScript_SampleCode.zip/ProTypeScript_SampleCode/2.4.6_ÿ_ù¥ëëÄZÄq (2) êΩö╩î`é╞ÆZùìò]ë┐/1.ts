const input1 = "123", input2 = "";

const input1isNotEmpty = !!input1;
console.log(input1isNotEmpty); // true と表示される
const input2isNotEmpty = !!input2;
console.log(input2isNotEmpty); // false と表示される