// true が表示される(a は o よりも文字コードが小さいため)
console.log("apple" < "orange");