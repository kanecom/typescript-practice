const left: number = 1;
const right: number = 2;

console.log(left === right); // false が表示される
console.log(left !== right); // true が表示される