const left1 = -5, right1 = 0;
console.log(left1 < right1); // true と表示される

const left2 = 100n, right2 = 50n;
console.log(left2 >= right2); // true と表示される

const left3 = -10, right3 = 0;
console.log(left3 > right3); // false と表示される

const left4 = 12n, right4 = 8n;
console.log(left4 <= right4); // false と表示される