const pair = <Left, Right>(left: Left, right: Right): [Left, Right] => [left, right];
// pは[string, number]型
const p = pair("uhyo", 26);