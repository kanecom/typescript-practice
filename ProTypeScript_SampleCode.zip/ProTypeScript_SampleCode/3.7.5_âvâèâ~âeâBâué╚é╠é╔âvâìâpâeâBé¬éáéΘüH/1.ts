const str = "Hello, world!";
console.log(str.length); // 13 と表示される