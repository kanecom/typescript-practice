type HasLength = { length: number };
const obj: HasLength = "foobar";