for (const i of sequence(1, 100)) {
  const message = getFizzBuzzString(i);
  console.log(message);
}