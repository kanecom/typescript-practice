const arr = [1, 10, 100];
console.log(arr.length); // 3 が表示される
arr.push(1000);
console.log(arr.length); // 4 が表示される